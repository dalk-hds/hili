chrome extension that helps highlighting the list of saved keywords
